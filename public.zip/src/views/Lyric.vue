<template>
    <div>
        歌词信息
    </div>
</template>
<script>
export default{
    name:'Lyric',

}
</script>